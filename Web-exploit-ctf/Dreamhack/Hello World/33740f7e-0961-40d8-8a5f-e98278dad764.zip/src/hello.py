import __hello__

__hello__.main()