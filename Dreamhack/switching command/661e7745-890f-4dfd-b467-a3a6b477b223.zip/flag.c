#include <stdio.h>

void main()
{
    puts("DH{**fake_flag**}\n");
}