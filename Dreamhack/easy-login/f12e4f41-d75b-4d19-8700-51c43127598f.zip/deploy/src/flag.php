<?php
$flag = "testflag";
?>